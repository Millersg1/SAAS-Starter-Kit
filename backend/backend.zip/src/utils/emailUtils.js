import nodemailer from 'nodemailer';

/**
 * Create email transporter
 * In production, configure with real SMTP settings
 */
const createTransporter = () => {
  // For development, use ethereal email (fake SMTP service)
  // In production, replace with real SMTP credentials from .env
  
  if (process.env.NODE_ENV === 'production') {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }
  
  // Development mode - log emails to console instead of sending
  return {
    sendMail: async (mailOptions) => {
      console.log('\n📧 Email would be sent (Development Mode): - emailUtils.js:26');
      console.log('To: - emailUtils.js:27', mailOptions.to);
      console.log('Subject: - emailUtils.js:28', mailOptions.subject);
      console.log('Content: - emailUtils.js:29', mailOptions.text || mailOptions.html);
      console.log('\n - emailUtils.js:30');
      return { messageId: 'dev-mode-' + Date.now() };
    }
  };
};

/**
 * Send email verification email
 * @param {string} email - Recipient email
 * @param {string} name - Recipient name
 * @param {string} token - Verification token
 */
export const sendVerificationEmail = async (email, name, token) => {
  const transporter = createTransporter();
  
  const verificationUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-email/${token}`;
  
  const mailOptions = {
    from: `${process.env.SMTP_FROM_NAME || 'ClientHub'} <${process.env.SMTP_FROM_EMAIL || 'noreply@clienthub.com'}>`,
    to: email,
    subject: 'Verify Your Email - ClientHub',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to ClientHub, ${name}!</h2>
        <p>Thank you for registering. Please verify your email address by clicking the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verificationUrl}" 
             style="background-color: #007bff; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Verify Email
          </a>
        </div>
        <p>Or copy and paste this link into your browser:</p>
        <p style="color: #666; word-break: break-all;">${verificationUrl}</p>
        <p style="color: #999; font-size: 12px; margin-top: 30px;">
          This link will expire in 24 hours. If you didn't create an account, please ignore this email.
        </p>
      </div>
    `,
    text: `Welcome to ClientHub, ${name}!\n\nPlease verify your email by visiting: ${verificationUrl}\n\nThis link will expire in 24 hours.`
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Verification email sent to: - emailUtils.js:74', email);
  } catch (error) {
    console.error('❌ Error sending verification email: - emailUtils.js:76', error);
    throw new Error('Failed to send verification email');
  }
};

/**
 * Send password reset email
 * @param {string} email - Recipient email
 * @param {string} name - Recipient name
 * @param {string} token - Reset token
 */
export const sendPasswordResetEmail = async (email, name, token) => {
  const transporter = createTransporter();
  
  const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password/${token}`;
  
  const mailOptions = {
    from: `${process.env.SMTP_FROM_NAME || 'ClientHub'} <${process.env.SMTP_FROM_EMAIL || 'noreply@clienthub.com'}>`,
    to: email,
    subject: 'Password Reset Request - ClientHub',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Password Reset Request</h2>
        <p>Hi ${name},</p>
        <p>You requested to reset your password. Click the button below to create a new password:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" 
             style="background-color: #dc3545; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Reset Password
          </a>
        </div>
        <p>Or copy and paste this link into your browser:</p>
        <p style="color: #666; word-break: break-all;">${resetUrl}</p>
        <p style="color: #999; font-size: 12px; margin-top: 30px;">
          This link will expire in 1 hour. If you didn't request a password reset, please ignore this email.
        </p>
      </div>
    `,
    text: `Hi ${name},\n\nYou requested to reset your password. Visit this link to create a new password:\n\n${resetUrl}\n\nThis link will expire in 1 hour.`
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Password reset email sent to: - emailUtils.js:120', email);
  } catch (error) {
    console.error('❌ Error sending password reset email: - emailUtils.js:122', error);
    throw new Error('Failed to send password reset email');
  }
};

/**
 * Send welcome email after email verification
 * @param {string} email - Recipient email
 * @param {string} name - Recipient name
 */
/**
 * Send invoice notification to client when invoice status is set to 'sent'
 */
export const sendInvoiceEmail = async (clientEmail, clientName, invoiceNumber, total, dueDate, portalUrl, brandName) => {
  const transporter = createTransporter();
  const formattedTotal = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(total);
  const formattedDue = dueDate ? new Date(dueDate).toLocaleDateString() : 'Upon receipt';

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `Invoice ${invoiceNumber} from ${brandName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Invoice ${invoiceNumber}</h2>
        <p>Hi ${clientName},</p>
        <p>You have a new invoice from <strong>${brandName}</strong>.</p>
        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Invoice #</strong></td><td style="padding:8px; border:1px solid #ddd;">${invoiceNumber}</td></tr>
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Amount Due</strong></td><td style="padding:8px; border:1px solid #ddd;">${formattedTotal}</td></tr>
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Due Date</strong></td><td style="padding:8px; border:1px solid #ddd;">${formattedDue}</td></tr>
        </table>
        ${portalUrl ? `<div style="text-align:center; margin:30px 0;"><a href="${portalUrl}" style="background-color:#2563eb; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">View Invoice in Portal</a></div>` : ''}
        <p style="color:#999; font-size:12px;">If you have any questions, please contact ${brandName} directly.</p>
      </div>
    `,
    text: `Hi ${clientName},\n\nYou have a new invoice from ${brandName}.\n\nInvoice #: ${invoiceNumber}\nAmount Due: ${formattedTotal}\nDue Date: ${formattedDue}\n\n${portalUrl ? `View in portal: ${portalUrl}` : ''}`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending invoice email:', error);
  }
};

/**
 * Send payment confirmation email to client
 */
export const sendPaymentConfirmationEmail = async (clientEmail, clientName, invoiceNumber, amountPaid, brandName) => {
  const transporter = createTransporter();
  const formattedAmount = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amountPaid);

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `Payment Received - Invoice ${invoiceNumber}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color:#16a34a;">Payment Confirmed ✓</h2>
        <p>Hi ${clientName},</p>
        <p>We've received your payment of <strong>${formattedAmount}</strong> for invoice ${invoiceNumber} from <strong>${brandName}</strong>.</p>
        <p>Thank you for your prompt payment!</p>
        <p style="color:#999; font-size:12px;">If you have any questions, please contact ${brandName} directly.</p>
      </div>
    `,
    text: `Hi ${clientName},\n\nWe've received your payment of ${formattedAmount} for invoice ${invoiceNumber}. Thank you!`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending payment confirmation email:', error);
  }
};

/**
 * Send project update notification to client
 */
export const sendProjectUpdateEmail = async (clientEmail, clientName, projectName, updateTitle, content, portalUrl, brandName) => {
  const transporter = createTransporter();

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `Project Update: ${projectName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Project Update</h2>
        <p>Hi ${clientName},</p>
        <p><strong>${brandName}</strong> has posted a new update on your project <strong>${projectName}</strong>.</p>
        <div style="background:#f3f4f6; border-left:4px solid #2563eb; padding:12px 16px; margin:20px 0;">
          <strong>${updateTitle}</strong>
          <p style="margin-top:8px;">${content}</p>
        </div>
        ${portalUrl ? `<div style="text-align:center; margin:30px 0;"><a href="${portalUrl}" style="background-color:#2563eb; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">View in Portal</a></div>` : ''}
      </div>
    `,
    text: `Hi ${clientName},\n\n${brandName} posted a project update on "${projectName}".\n\n${updateTitle}\n${content}\n\n${portalUrl ? `View in portal: ${portalUrl}` : ''}`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending project update email:', error);
  }
};

/**
 * Send failed payment alert to brand owner
 */
export const sendFailedPaymentEmail = async (ownerEmail, ownerName, brandName, amount, currency) => {
  const transporter = createTransporter();
  const formattedAmount = new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(amount);

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: ownerEmail,
    subject: `Action Required: Payment Failed for ${brandName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color:#dc2626;">Payment Failed</h2>
        <p>Hi ${ownerName},</p>
        <p>A payment of <strong>${formattedAmount}</strong> for your <strong>${brandName}</strong> subscription has failed.</p>
        <p>Please update your payment method to avoid service interruption.</p>
        <div style="text-align:center; margin:30px 0;">
          <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/subscriptions" style="background-color:#dc2626; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">Update Payment Method</a>
        </div>
      </div>
    `,
    text: `Hi ${ownerName},\n\nA payment of ${formattedAmount} for your ${brandName} subscription has failed. Please update your payment method.`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending failed payment email:', error);
  }
};

/**
 * Send trial ending reminder to brand owner
 */
export const sendTrialEndingEmail = async (ownerEmail, ownerName, brandName, trialEndDate) => {
  const transporter = createTransporter();
  const formattedDate = new Date(trialEndDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: ownerEmail,
    subject: `Your ${brandName} trial ends on ${formattedDate}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Your Trial is Ending Soon</h2>
        <p>Hi ${ownerName},</p>
        <p>Your trial for <strong>${brandName}</strong> ends on <strong>${formattedDate}</strong>.</p>
        <p>Add a payment method to continue using all features without interruption.</p>
        <div style="text-align:center; margin:30px 0;">
          <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/subscriptions" style="background-color:#2563eb; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">Add Payment Method</a>
        </div>
      </div>
    `,
    text: `Hi ${ownerName},\n\nYour trial for ${brandName} ends on ${formattedDate}. Add a payment method to keep your account active.`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending trial ending email:', error);
  }
};

/**
 * Send portal access credentials to client
 */
export const sendPortalAccessEmail = async (clientEmail, clientName, brandName, portalUrl, password) => {
  const transporter = createTransporter();

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `You've been invited to the ${brandName} client portal`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to the ${brandName} Client Portal</h2>
        <p>Hi ${clientName},</p>
        <p><strong>${brandName}</strong> has set up a client portal for you. You can now view your projects, documents, invoices, and messages online.</p>
        <div style="background:#f3f4f6; padding:16px; border-radius:8px; margin:20px 0;">
          <p style="margin:0;"><strong>Your login credentials:</strong></p>
          <p style="margin:8px 0 0;">Email: <strong>${clientEmail}</strong></p>
          <p style="margin:4px 0 0;">Password: <strong>${password}</strong></p>
        </div>
        <div style="text-align:center; margin:30px 0;">
          <a href="${portalUrl}" style="background-color:#2563eb; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">Access Your Portal</a>
        </div>
        <p style="color:#999; font-size:12px;">We recommend changing your password after your first login. Contact ${brandName} if you have any questions.</p>
      </div>
    `,
    text: `Hi ${clientName},\n\n${brandName} has set up a client portal for you.\n\nEmail: ${clientEmail}\nPassword: ${password}\n\nAccess your portal at: ${portalUrl}`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending portal access email:', error);
  }
};

/**
 * Send overdue invoice reminder to client
 */
export const sendOverdueReminderEmail = async (clientEmail, clientName, invoiceNumber, amountDue, daysOverdue, portalUrl, brandName) => {
  const transporter = createTransporter();
  const formattedAmount = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amountDue);

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `Action Required: Invoice ${invoiceNumber} is ${daysOverdue} day${daysOverdue !== 1 ? 's' : ''} overdue`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color:#ea580c;">Payment Reminder</h2>
        <p>Hi ${clientName},</p>
        <p>This is a reminder that invoice <strong>${invoiceNumber}</strong> from <strong>${brandName}</strong> is now <strong>${daysOverdue} day${daysOverdue !== 1 ? 's' : ''} overdue</strong>.</p>
        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Invoice #</strong></td><td style="padding:8px; border:1px solid #ddd;">${invoiceNumber}</td></tr>
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Amount Due</strong></td><td style="padding:8px; border:1px solid #ddd; color:#dc2626; font-weight:bold;">${formattedAmount}</td></tr>
        </table>
        <p>Please arrange payment at your earliest convenience to avoid any service interruption.</p>
        ${portalUrl ? `<div style="text-align:center; margin:30px 0;"><a href="${portalUrl}" style="background-color:#ea580c; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">Pay Now</a></div>` : ''}
        <p style="color:#999; font-size:12px;">If you have already made payment, please disregard this notice. Contact ${brandName} if you have any questions.</p>
      </div>
    `,
    text: `Hi ${clientName},\n\nInvoice ${invoiceNumber} from ${brandName} is ${daysOverdue} day${daysOverdue !== 1 ? 's' : ''} overdue.\nAmount Due: ${formattedAmount}\n\n${portalUrl ? `Pay now: ${portalUrl}` : ''}\n\nIf you have already paid, please disregard this notice.`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending overdue reminder email:', error);
  }
};

/**
 * Send proposal notification to client
 */
export const sendProposalEmail = async (clientEmail, clientName, proposalTitle, total, expiryDate, portalUrl, brandName) => {
  const transporter = createTransporter();
  const formattedTotal = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(total);
  const formattedExpiry = expiryDate ? new Date(expiryDate).toLocaleDateString() : 'No expiry';

  const mailOptions = {
    from: process.env.EMAIL_FROM || 'noreply@clienthub.app',
    to: clientEmail,
    subject: `Proposal: ${proposalTitle} from ${brandName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>New Proposal</h2>
        <p>Hi ${clientName},</p>
        <p><strong>${brandName}</strong> has sent you a proposal for your review.</p>
        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Proposal</strong></td><td style="padding:8px; border:1px solid #ddd;">${proposalTitle}</td></tr>
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Total Value</strong></td><td style="padding:8px; border:1px solid #ddd;">${formattedTotal}</td></tr>
          <tr><td style="padding:8px; border:1px solid #ddd;"><strong>Expires</strong></td><td style="padding:8px; border:1px solid #ddd;">${formattedExpiry}</td></tr>
        </table>
        <p>Review the proposal and accept or decline through your client portal.</p>
        ${portalUrl ? `<div style="text-align:center; margin:30px 0;"><a href="${portalUrl}" style="background-color:#2563eb; color:white; padding:12px 30px; text-decoration:none; border-radius:5px; display:inline-block;">Review Proposal</a></div>` : ''}
        <p style="color:#999; font-size:12px;">If you have any questions, please contact ${brandName} directly.</p>
      </div>
    `,
    text: `Hi ${clientName},\n\n${brandName} has sent you a proposal: "${proposalTitle}"\nTotal: ${formattedTotal}\nExpires: ${formattedExpiry}\n\n${portalUrl ? `Review at: ${portalUrl}` : ''}`
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending proposal email:', error);
  }
};

export const sendWelcomeEmail = async (email, name) => {
  const transporter = createTransporter();
  
  const mailOptions = {
    from: `${process.env.SMTP_FROM_NAME || 'ClientHub'} <${process.env.SMTP_FROM_EMAIL || 'noreply@clienthub.com'}>`,
    to: email,
    subject: 'Welcome to ClientHub!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to ClientHub, ${name}! 🎉</h2>
        <p>Your email has been verified successfully. You can now access all features of your account.</p>
        <p>Get started by:</p>
        <ul>
          <li>Completing your profile</li>
          <li>Exploring the dashboard</li>
          <li>Connecting with your team</li>
        </ul>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/dashboard" 
             style="background-color: #28a745; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Go to Dashboard
          </a>
        </div>
        <p>If you have any questions, feel free to reach out to our support team.</p>
      </div>
    `,
    text: `Welcome to ClientHub, ${name}!\n\nYour email has been verified successfully. Visit your dashboard to get started.`
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Welcome email sent to: - emailUtils.js:164', email);
  } catch (error) {
    console.error('❌ Error sending welcome email: - emailUtils.js:166', error);
    // Don't throw error for welcome email - it's not critical
  }
};
