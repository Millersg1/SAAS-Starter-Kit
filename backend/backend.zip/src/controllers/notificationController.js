import { query } from '../config/database.js';
import { getBrandMember } from '../models/brandModel.js';
import { AppError, catchAsync } from '../middleware/errorHandler.js';

/**
 * GET /api/notifications/:brandId
 * Aggregate notifications: unread messages + overdue invoices
 */
export const getNotifications = catchAsync(async (req, res, next) => {
  const { brandId } = req.params;
  const userId = req.user.id;

  const member = await getBrandMember(brandId, userId);
  if (!member) return next(new AppError('You do not have access to this brand', 403));

  const notifications = [];

  // Unread message threads
  try {
    const msgResult = await query(
      `SELECT COUNT(*) as count
       FROM message_threads
       WHERE brand_id = $1 AND unread_count > 0 AND status = 'open'`,
      [brandId]
    );
    const unreadCount = parseInt(msgResult.rows[0]?.count || 0);
    if (unreadCount > 0) {
      notifications.push({
        type: 'messages',
        title: 'Unread Messages',
        body: `${unreadCount} thread${unreadCount !== 1 ? 's' : ''} with unread messages`,
        link: '/messages',
        count: unreadCount,
      });
    }
  } catch (err) {
    console.error('Notification: failed to fetch unread messages', err.message);
  }

  // Overdue invoices
  try {
    const invResult = await query(
      `SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
       FROM invoices
       WHERE brand_id = $1 AND status = 'overdue'`,
      [brandId]
    );
    const overdueCount = parseInt(invResult.rows[0]?.count || 0);
    if (overdueCount > 0) {
      const total = parseFloat(invResult.rows[0]?.total || 0);
      notifications.push({
        type: 'invoices',
        title: 'Overdue Invoices',
        body: `${overdueCount} overdue invoice${overdueCount !== 1 ? 's' : ''} totalling $${total.toFixed(0)}`,
        link: '/invoices',
        count: overdueCount,
      });
    }
  } catch (err) {
    console.error('Notification: failed to fetch overdue invoices', err.message);
  }

  res.status(200).json({
    status: 'success',
    data: {
      notifications,
      total: notifications.reduce((sum, n) => sum + n.count, 0),
    },
  });
});

/**
 * GET /api/notifications/:brandId/count
 * Lightweight unread count for badge polling
 */
export const getUnreadCount = catchAsync(async (req, res, next) => {
  const { brandId } = req.params;
  const userId = req.user.id;

  const member = await getBrandMember(brandId, userId);
  if (!member) return next(new AppError('You do not have access to this brand', 403));

  let count = 0;

  try {
    const msgResult = await query(
      `SELECT COUNT(*) as count FROM message_threads
       WHERE brand_id = $1 AND unread_count > 0 AND status = 'open'`,
      [brandId]
    );
    count += parseInt(msgResult.rows[0]?.count || 0);
  } catch (err) { /* ignore */ }

  try {
    const invResult = await query(
      `SELECT COUNT(*) as count FROM invoices
       WHERE brand_id = $1 AND status = 'overdue'`,
      [brandId]
    );
    count += parseInt(invResult.rows[0]?.count || 0);
  } catch (err) { /* ignore */ }

  res.status(200).json({
    status: 'success',
    data: { count },
  });
});
