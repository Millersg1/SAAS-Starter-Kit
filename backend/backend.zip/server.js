import app from './src/app.js';
import { testConnection, closePool } from './src/config/database.js';
import { startRecurringInvoiceCron } from './src/utils/recurringInvoices.js';
import { startOverdueReminderCron } from './src/utils/overdueReminders.js';
import dotenv from 'dotenv';

dotenv.config();

const PORT = process.env.PORT || 5000;

// Start server
const startServer = async () => {
  try {
    // Test database connection
    console.log('🔍 Testing database connection... - server.js:13');
    const dbConnected = await testConnection();
    
    if (!dbConnected) {
      console.error('❌ Failed to connect to database. Exiting... - server.js:17');
      process.exit(1);
    }

    // Start recurring invoice cron job
    startRecurringInvoiceCron();

    // Start overdue invoice reminder cron job
    startOverdueReminderCron();

    // Start Express server
    const server = app.listen(PORT, () => {
      console.log('🚀 ClientHub API Server Started - server.js:23');
      console.log(`📡 Server running on port ${PORT} - server.js:24`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'} - server.js:25`);
      console.log(`🔗 API URL: http://localhost:${PORT} - server.js:26`);
      console.log(`💚 Health check: http://localhost:${PORT}/health - server.js:27`);
      console.log('');
      console.log('Press CTRL+C to stop the server - server.js:29');
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal) => {
      console.log(`\n${signal} received. Starting graceful shutdown... - server.js:34`);
      
      server.close(async () => {
        console.log('✅ HTTP server closed - server.js:37');
        
        await closePool();
        console.log('✅ Database connections closed - server.js:40');
        
        console.log('👋 Server shutdown complete - server.js:42');
        process.exit(0);
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error('⚠️  Forced shutdown after timeout - server.js:48');
        process.exit(1);
      }, 10000);
    };

    // Handle shutdown signals
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    // Handle uncaught exceptions
    process.on('uncaughtException', (err) => {
      console.error('💥 UNCAUGHT EXCEPTION! Shutting down... - server.js:59');
      console.error(err.name, err.message);
      console.error(err.stack);
      process.exit(1);
    });

    // Handle unhandled promise rejections
    process.on('unhandledRejection', (err) => {
      console.error('💥 UNHANDLED REJECTION! Shutting down... - server.js:67');
      console.error(err.name, err.message);
      server.close(() => {
        process.exit(1);
      });
    });

  } catch (error) {
    console.error('❌ Failed to start server: - server.js:75', error);
    process.exit(1);
  }
};

// Start the server
startServer();
